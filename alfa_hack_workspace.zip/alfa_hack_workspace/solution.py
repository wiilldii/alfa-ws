"""Alfa Hack: reproducible autonomous tabular AutoResearch baseline.

Usage: python solution.py path/to/task.md
Creates path/to/submission.csv. Works offline, CPU-only, no external weights.
Optional organizer-provided LLM feedback if OPENAI_MODEL/API_KEY/BASE_URL are set.
"""
import json
import os
import re
import sys
import time
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import (mean_squared_error, mean_absolute_error, f1_score,
                             accuracy_score, roc_auc_score, log_loss, r2_score)
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore", category=FutureWarning)
START = time.monotonic()
RNG = np.random.default_rng(2026)
SEED = 2026
CPU = min(8, os.cpu_count() or 8)


def log(*args):
    print('[AlfaAgent %ds]' % int(time.monotonic() - START), *args, flush=True)


def path_for(base, name):
    p = base / name
    if p.exists():
        return p
    # Some task.md documents refer to a nested layout while supplied files
    # are placed directly alongside the task document.
    found = list(base.rglob(name))
    if len(found) == 1:
        return found[0]
    raise FileNotFoundError(f"Could not locate {name} relative to {base}")


def detect_target(train, test, sample, task_text):
    id_columns = [c for c in sample.columns if c in test.columns]
    result_cols = [c for c in sample.columns if c not in id_columns]
    candidates = [c for c in train if c not in test]
    if len(result_cols) == 1 and result_cols[0] in train:
        return result_cols[0], id_columns, result_cols
    if len(candidates) == 1:
        return candidates[0], id_columns, result_cols
    raise ValueError('Ambiguous target: ' + repr(candidates))


def problem_type(y, task_text):
    desc = task_text.lower()
    if 'классификац' in desc or 'classification' in desc:
        return 'classification'
    if 'регресси' in desc or 'regression' in desc:
        return 'regression'
    if not pd.api.types.is_numeric_dtype(y):
        return 'classification'
    if pd.api.types.is_integer_dtype(y) and y.nunique() <= min(40, max(2, len(y) // 50)):
        return 'classification'
    return 'regression'


def metric_type(problem, task_text):
    s = task_text.lower()
    if problem == 'regression':
        if 'rmsle' in s: return 'rmsle'
        if 'mae' in s and 'rmse' not in s: return 'mae'
        if 'mape' in s and 'rmse' not in s: return 'mape'
        if 'r2_score' in s or 'r²' in s: return 'r2'
        return 'rmse'
    if 'macro' in s and ('f1' in s or 'f-1' in s): return 'macro_f1'
    if 'weighted' in s and 'f1' in s: return 'weighted_f1'
    if 'roc_auc' in s or 'roc-auc' in s: return 'auc'
    if 'logloss' in s or 'log_loss' in s: return 'logloss'
    if 'accuracy' in s and 'f1' not in s: return 'accuracy'
    return 'macro_f1' if y_classes > 2 else 'macro_f1'


def prep_columns(train, test, id_cols, target):
    features = [c for c in test.columns if c in train.columns and c != target and c not in id_cols]
    if not features:
        raise ValueError('No usable feature columns')
    xtr = train[features].copy()
    xte = test[features].copy()
    cats = []
    for col in features:
        a, b = xtr[col], xte[col]
        if not (pd.api.types.is_object_dtype(a) or isinstance(a.dtype, pd.CategoricalDtype) or
                pd.api.types.is_string_dtype(a)):
            xtr[col] = pd.to_numeric(a, errors='coerce').replace([np.inf, -np.inf], np.nan)
            xte[col] = pd.to_numeric(b, errors='coerce').replace([np.inf, -np.inf], np.nan)
            continue
        # Numeric strings are common in unfamiliar datasets. Avoid losing them.
        numeric = pd.to_numeric(a, errors='coerce')
        if a.notna().sum() > 0 and numeric.notna().sum() / a.notna().sum() > 0.985:
            xtr[col] = numeric.replace([np.inf, -np.inf], np.nan)
            xte[col] = pd.to_numeric(b, errors='coerce').replace([np.inf, -np.inf], np.nan)
        else:
            cats.append(col)
            xtr[col] = a.astype('string').fillna('__MISSING__').astype(str)
            xte[col] = b.astype('string').fillna('__MISSING__').astype(str)
    # Robust to columns that are entirely missing or constant in train.
    drop = [c for c in features if xtr[c].nunique(dropna=False) <= 1]
    xtr = xtr.drop(columns=drop)
    xte = xte.drop(columns=drop)
    cats = [c for c in cats if c not in drop]
    if not len(xtr.columns):
        raise ValueError('All features are constant')
    log('Features:', len(xtr.columns), 'categorical:', len(cats), 'dropped constant:', len(drop))
    return xtr, xte, cats


def lightgbm_tables(x, xt, cats):
    x = x.copy()
    xt = xt.copy()
    for c in cats:
        # Categories learned from both unlabeled and labeled rows, no target leakage.
        all_categories = pd.Index(pd.concat([x[c], xt[c]], ignore_index=True).unique())
        x[c] = pd.Categorical(x[c], categories=all_categories)
        xt[c] = pd.Categorical(xt[c], categories=all_categories)
    return x, xt


def quality(y, pred, metric, proba=None):
    if metric == 'rmse': return -float(np.sqrt(mean_squared_error(y, pred)))
    if metric == 'mae': return -float(mean_absolute_error(y, pred))
    if metric == 'rmsle':
        return -float(np.sqrt(mean_squared_error(np.log1p(np.maximum(0, y)), np.log1p(np.maximum(0, pred)))))
    if metric == 'mape':
        return -float(np.mean(np.abs((y-pred) / np.maximum(np.abs(y), 1e-7))))
    if metric == 'r2': return float(r2_score(y, pred))
    if metric == 'accuracy': return float(accuracy_score(y, pred))
    if metric == 'weighted_f1': return float(f1_score(y, pred, average='weighted', zero_division=0))
    if metric == 'auc' and proba is not None:
        try: return float(roc_auc_score(y, proba[:, 1] if proba.shape[1] == 2 else proba,
                                        multi_class='ovr' if proba.shape[1] > 2 else 'raise'))
        except ValueError: pass
    if metric == 'logloss' and proba is not None:
        return -float(log_loss(y, proba, labels=np.arange(proba.shape[1])))
    return float(f1_score(y, pred, average='macro', zero_division=0))


def improve_class_thresholds(proba, y, metric):
    """Validation-only threshold reweighting for imbalanced classification."""
    nclass = proba.shape[1]
    weights = np.ones(nclass)
    pred = np.argmax(proba, axis=1)
    base = quality(y, pred, metric, proba)
    if metric not in ('macro_f1','weighted_f1'):
        return weights, base
    if len(y) < 100 or nclass > 40:
        return weights, base
    score = base
    # Coordinate ascent; avoids a huge, overfitted random hyperparameter search.
    for _ in range(2):
        changed = False
        for cls in range(nclass):
            if np.sum(y == cls) < 5:
                continue
            weight, best = weights[cls], score
            for factor in (0.55, 0.75, 0.9, 1.12, 1.35, 1.7, 2.2):
                w = weights.copy()
                w[cls] = np.clip(weights[cls] * factor, 0.15, 5.0)
                pred_test = np.argmax(proba * w, axis=1)
                sc = quality(y, pred_test, metric)
                if sc > best + 0.0003:
                    best, weight = sc, w[cls]
            if best > score + 0.0003:
                weights[cls], score, changed = weight, best, True
        if not changed: break
    # Guard against validation-specific overfit from rare labels: require
    # a nontrivial gain before changing default thresholds.
    if score - base < 0.003:
        return np.ones(nclass), base
    return weights, score


def build_lgb(problem, nclasses, n, cat_features, iterations=750):
    import lightgbm as lgb
    params = dict(n_estimators=iterations, learning_rate=0.045, num_leaves=31,
                  max_depth=-1, min_child_samples=35, colsample_bytree=0.9,
                  subsample=0.9, subsample_freq=1, reg_lambda=3.0,
                  verbosity=-1, random_state=SEED, n_jobs=CPU)
    if problem == 'classification':
        if nclasses > 2: params.update(objective='multiclass', num_class=nclasses)
        else: params.update(objective='binary')
        return lgb.LGBMClassifier(**params)
    params['objective'] = 'regression'
    return lgb.LGBMRegressor(**params)


def build_cat(problem, nclasses, iterations=650):
    from catboost import CatBoostRegressor, CatBoostClassifier
    args = dict(iterations=iterations, learning_rate=0.055, depth=7 if problem == 'regression' else 6,
                l2_leaf_reg=5, random_seed=SEED, thread_count=CPU, verbose=False,
                allow_writing_files=False)
    if problem == 'classification':
        args['loss_function'] = 'MultiClass' if nclasses > 2 else 'Logloss'
        return CatBoostClassifier(**args)
    args['loss_function'] = 'RMSE'
    return CatBoostRegressor(**args)


def predict_model(model, x, classification, nclasses):
    if classification:
        p = np.asarray(model.predict_proba(x))
        if p.ndim == 1:
            p = np.column_stack([1-p, p])
        return np.argmax(p, axis=1), p
    return np.asarray(model.predict(x)).reshape(-1), None


def maybe_organizer_llm_feedback(metadata, experiments):
    # Uses only the organizer-supplied API; never sends full datasets.
    required = ('OPENAI_API_KEY', 'OPENAI_BASE_URL', 'OPENAI_MODEL')
    if not all(os.environ.get(k) for k in required):
        log('Organizer LLM env not present; autonomous validation loop continues offline')
        return None
    try:
        from openai import OpenAI
        prompt = ('You are an AutoResearch agent working within 8 CPU / 32GB / 3h. '
                  'Look at problem metadata and observed validation results. '
                  'Suggest one specific next experiment for better generalization. '
                  'Do not suggest any pretrained model or external data. '
                  'Keep it under 90 words.\n' + json.dumps({'meta':metadata, 'experiments':experiments},
                                                      ensure_ascii=False, default=str)[:7500])
        client = OpenAI(timeout=20, max_retries=0)
        response = client.chat.completions.create(model=os.environ['OPENAI_MODEL'],
            messages=[{'role':'user','content':prompt}], max_tokens=220)
        advice = str(response.choices[0].message.content or '')[:1500]
        log('LLM hypothesis:', advice.replace('\n', ' '))
        return advice
    except Exception as e:
        log('Organizer LLM unavailable:', str(e)[:200])
        return None


def main():
    global y_classes
    task_path = Path(sys.argv[1] if len(sys.argv)>1 else 'task.md').resolve()
    base = task_path.parent
    description = task_path.read_text('utf-8') if task_path.exists() else ''
    train = pd.read_csv(path_for(base, 'train.csv'), low_memory=False)
    test = pd.read_csv(path_for(base, 'test.csv'), low_memory=False)
    sample = pd.read_csv(path_for(base, 'sample_submission.csv'), nrows=20)
    target, id_cols, result_cols = detect_target(train, test, sample, description)
    if target not in train: raise ValueError('Target not in training CSV')
    y = train[target]
    problem = problem_type(y, description)
    if problem == 'classification':
        encoder = LabelEncoder()
        yy = encoder.fit_transform(y.astype(str))
        y_classes = len(encoder.classes_)
        nclasses = y_classes
    else:
        yy = pd.to_numeric(y, errors='coerce').to_numpy()
        nclasses = 0
        good = np.isfinite(yy)
        train = train.loc[good].reset_index(drop=True)
        yy = yy[good]
    metric = metric_type(problem, description)
    log('Started task:', target, problem, metric, 'train/test:',len(train),len(test))
    x, xt, cats = prep_columns(train, test, id_cols, target)
    x_lgb, xt_lgb = lightgbm_tables(x,xt,cats)
    stratify = yy if problem == 'classification' and pd.Series(yy).value_counts().min() >= 5 else None
    indices = np.arange(len(yy))
    tr, va = train_test_split(indices, test_size=0.20, random_state=SEED, stratify=stratify)
    # Detect true forward-in-time evaluation automatically. This is critical
    # when the entire test is a future year rather than a random holdout.
    split_kind = 'random_80_20'
    for col in x.columns:
        name = col.lower()
        if not (name in ('year', 'year_factor', 'year_id', 'time_period') or
                name.endswith('_year')):
            continue
        try:
            a = pd.to_numeric(train[col], errors='coerce')
            b = pd.to_numeric(test[col], errors='coerce')
            years = sorted(a.dropna().unique())
            if (3 <= len(years) <= 50 and a.notna().mean() > .99 and
                b.notna().mean() > .99 and b.min() > a.max() and
                (a == years[-1]).mean() > .08 and
                (a < years[-1]).mean() > .30):
                tr = np.flatnonzero((a < years[-1]).to_numpy())
                va = np.flatnonzero((a == years[-1]).to_numpy())
                split_kind = f'forward_temporal_{col}: train < {years[-1]}, validation = {years[-1]}'
                log('Detected test future period, using time-forward validation:', split_kind)
                break
        except Exception as exc:
            log('Temporal-split check skipped:', str(exc)[:90])
    experiments = []
    best = dict(score=-np.inf, model=None, weights=None, family=None, iteration=None)
    created_submission = False

    def save_predictions(pred):
        nonlocal created_submission
        if problem == 'classification':
            pred = encoder.inverse_transform(np.asarray(pred, dtype=int))
        else:
            pred = np.asarray(pred, dtype=float)
            pred = np.nan_to_num(pred, nan=float(np.nanmedian(yy)),
                                 posinf=float(np.nanmax(yy)), neginf=float(np.nanmin(yy)))
            if np.nanmin(yy) >= 0:
                pred = np.maximum(pred, 0)
        if len(pred) != len(test): raise RuntimeError('Prediction size mismatch')
        submission = pd.DataFrame({c: test[c].values for c in id_cols})
        # Typical output has one target column, but use template order exactly.
        submission[result_cols[0] if result_cols else target] = pred
        submission = submission[list(sample.columns)]
        if len(submission) != len(test) or submission.isna().any().any():
            raise RuntimeError('Invalid submission')
        out = base / 'submission.csv'
        tmp = base / 'submission.tmp.csv'
        submission.to_csv(tmp, index=False)
        os.replace(tmp, out)
        created_submission = True
        log('SUCCESS saved:', str(out), 'rows:', len(submission))

    def score_and_track(family, model, xv):
        nonlocal best
        predictions, proba = predict_model(model,xv,problem=='classification',nclasses)
        if problem == 'classification':
            weights, score = improve_class_thresholds(proba,yy[va],metric)
            base_score = quality(yy[va], predictions, metric, proba)
        else:
            weights, score = None, quality(yy[va],predictions,metric)
            base_score = score
        if not np.isfinite(score): raise RuntimeError('Non-finite metric')
        niter = getattr(model, 'best_iteration_', None)
        if niter is None and family == 'catboost':
            niter = model.get_best_iteration()
        if not niter or niter < 30:
            niter = getattr(model, 'n_estimators', 650) if family=='lightgbm' else 650
        if family=='lightgbm': niter = min(1400, max(140, int(niter)+35))
        else: niter = min(1100, max(140, int(niter)+35))
        experiment = dict(family=family, score=round(score,6), raw_score=round(base_score,6),
                          iterations=niter, weights=(weights.round(3).tolist() if weights is not None else None))
        experiments.append(experiment)
        log('EVALUATED:',experiment)
        if score > best['score'] + 0.001:
            best.update(score=score, model=model, weights=weights, family=family, iteration=niter)
            return True
        return False

    def full_retrain(family):
        if family=='lightgbm':
            model = build_lgb(problem,nclasses,len(train),cats,iterations=best['iteration'])
            model.fit(x_lgb,yy,categorical_feature=cats if cats else 'auto')
            pred,proba = predict_model(model,xt_lgb,problem=='classification',nclasses)
        else:
            model = build_cat(problem,nclasses,iterations=best['iteration'])
            model.fit(x,yy,cat_features=cats if cats else None)
            pred,proba = predict_model(model,xt,problem=='classification',nclasses)
        if proba is not None and best['weights'] is not None:
            pred=np.argmax(proba*best['weights'],axis=1)
        save_predictions(pred)

    # First experiment: fast, reliable LightGBM. Always create an output before
    # spending further time researching other model families.
    try:
        import lightgbm as lgb
        model=build_lgb(problem,nclasses,len(train),cats)
        fit_args = dict(eval_set=[(x_lgb.iloc[va], yy[va])],
                        callbacks=[lgb.early_stopping(75, verbose=False)],
                        categorical_feature=cats if cats else 'auto')
        model.fit(x_lgb.iloc[tr],yy[tr],**fit_args)
        score_and_track('lightgbm',model,x_lgb.iloc[va])
        full_retrain('lightgbm')
    except Exception as exc:
        log('LightGBM failed:',str(exc)[:500])
        traceback.print_exc()

    # AutoResearch experiment: compare a different inductive bias, CatBoost,
    # with equal split and metrics. Replace initial output only when better.
    if time.monotonic()-START < 5400 and len(train) < 600000:
        try:
            model=build_cat(problem,nclasses)
            model.fit(x.iloc[tr],yy[tr],cat_features=cats if cats else None,
                      eval_set=(x.iloc[va],yy[va]),early_stopping_rounds=70,verbose=False)
            is_better = score_and_track('catboost',model,x.iloc[va])
            if is_better or not created_submission:
                full_retrain('catboost')
        except Exception as exc:
            log('CatBoost failed:',str(exc)[:500])
            traceback.print_exc()

    # Optional LLM-in-the-loop research log for later iterations; no risky code
    # generation and no model-key dependency in the first submit.
    feedback = maybe_organizer_llm_feedback(
        {'task':target,'type':problem,'metric':metric,'split':split_kind,'rows':len(train),
         'features':x.columns.tolist(),'num_classes':nclasses},experiments)
    history = {'task':target,'problem':problem,'metric':metric,'validation_split':split_kind,'experiments':experiments,
               'best_family':best['family'],'best_score':best['score'],
               'elapsed_seconds':round(time.monotonic()-START,2),'llm_feedback':feedback}
    try:
        (base/'agent_experiments.json').write_text(json.dumps(history,ensure_ascii=False,indent=2),'utf-8')
    except Exception: pass
    if not created_submission:
        # Guaranteed last resort: better an appropriately formatted baseline
        # than a crash (e.g. on a previously unseen private schema).
        if problem == 'classification':
            default = np.argmax(np.bincount(yy))
            save_predictions(np.full(len(test),default))
        else:
            save_predictions(np.full(len(test),float(np.mean(yy))))
    log('DONE, best family:',best['family'],'metric:',best['score'])

if __name__ == '__main__':
    main()
