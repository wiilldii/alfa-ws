"""Create ZIP for platform: solution.py must be at ZIP root.
Run: python scripts/package_submission.py
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default=str(ROOT / 'submissions' / 'solution_upload.zip'))
    args = parser.parse_args()
    target = Path(args.out).resolve()
    target.parent.mkdir(parents=True,exist_ok=True)
    with ZipFile(target,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
        z.write(ROOT / 'solution.py', arcname='solution.py')
    with ZipFile(target) as z:
        assert z.namelist() == ['solution.py']
    print(f'Created platform ZIP: {target}')

if __name__ == '__main__':
    main()
