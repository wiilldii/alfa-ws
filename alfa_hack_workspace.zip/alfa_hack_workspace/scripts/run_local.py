"""Run current agent locally on a chosen public task.
Examples:
    python scripts/run_local.py regression
    python scripts/run_local.py classification
"""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
TASKS = {
    "regression": ROOT / "data" / "Регрессия" / "task.md",
    "classification": ROOT / "data" / "Многоклассовая классификация" / "task.md",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("task", choices=[*TASKS, "both"])
    args = parser.parse_args()
    tasks = TASKS if args.task == "both" else {args.task: TASKS[args.task]}
    for name, path in tasks.items():
        print(f"\n=== Task: {name} ===", flush=True)
        subprocess.run([sys.executable, str(ROOT / "solution.py"), str(path)], cwd=ROOT, check=True)
        subprocess.run([sys.executable, str(ROOT / "scripts" / "check_submission.py"), str(path)], cwd=ROOT, check=True)

if __name__ == "__main__":
    main()
