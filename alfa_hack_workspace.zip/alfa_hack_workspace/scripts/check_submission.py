"""Verify submission.csv against sample_submission.csv and test.csv."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd


def check(task_md):
    task_dir = Path(task_md).resolve().parent
    test = pd.read_csv(task_dir / "test.csv")
    sample = pd.read_csv(task_dir / "sample_submission.csv", nrows=3)
    pred_path = task_dir / "submission.csv"
    if not pred_path.exists():
        raise FileNotFoundError(f"Missing submission: {pred_path}")
    pred = pd.read_csv(pred_path)
    assert list(pred.columns) == list(sample.columns), f"Column mismatch: {pred.columns.tolist()}"
    assert len(pred) == len(test), f"Expected {len(test)} rows, got {len(pred)}"
    assert not pred.isna().any().any(), "Submission has missing values"
    id_cols = [c for c in sample.columns if c in test.columns]
    target_cols = [c for c in sample.columns if c not in id_cols]
    for col in id_cols:
        assert pred[col].equals(test[col]), f"Mismatched ID/order in {col}"
        assert not pred[col].duplicated().any(), f"Duplicate identifiers: {col}"
    if len(target_cols) == 1:
        t = target_cols[0]
        if t == "site_eui":
            numeric = pd.to_numeric(pred[t],errors='coerce')
            assert np.isfinite(numeric.to_numpy()).all(), 'Regression output contains NaN / inf / nonnumeric'
        elif t == "attack_cat":
            labels = set(pd.read_csv(task_dir/'train.csv',usecols=[t])[t].dropna().unique())
            assert set(pred[t].unique()) <= labels, 'Unexpected class labels'
    print(f"OK: {pred_path} | rows={len(pred)} | columns={pred.columns.tolist()}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python scripts/check_submission.py data/<task>/task.md")
    check(sys.argv[1])
