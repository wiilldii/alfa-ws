# Alfa Hack — рабочая папка ML-агента

Это рабочая копия **текущей** версии решения из `alfa_hack_first_submit_improved.zip`.
`solution.py` перенесён без изменений. Рабочая папка содержит данные обеих публичных задач и служебные скрипты.

## Структура

```text
alfa_hack_workspace/
├── solution.py                   # актуальное решение, запуск на платформе
├── README.md                     # этот документ
├── requirements.txt              # оригинальный список разрешённых библиотек
├── requirements-local.txt        # минимальные локальные зависимости
├── data/
│   ├── Регрессия/                 # train/test/task.md/data_dictionary/sample_submission
│   └── Многоклассовая классификация/ # аналогично
├── reference/
│   ├── baseline.py               # оригинальный baseline организаторов
│   └── requirements_platform.txt # копия requirements из архива
├── scripts/
│   ├── run_local.py              # запуск одной или двух задач
│   ├── check_submission.py       # контроль формата CSV
│   └── package_submission.py     # собрать ZIP для платформы
├── submissions/
│   └── solution_upload.zip       # ZIP только с solution.py
├── outputs/                      # рабочая папка под отчёты (пока пустая)
└── docs/
    └── CURRENT_STATUS.md        # ограничения и дальнейшие шаги
```

## Быстрый старт (Windows PowerShell)

Требуется Python **3.12**, установленный локально. Откройте терминал в папке `alfa_hack_workspace`:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-local.txt
python scripts/run_local.py regression
python scripts/run_local.py classification
python scripts/package_submission.py
```

Если PowerShell запрещает активацию, можно запускать `.\.venv\Scripts\python.exe` вместо `python`.

## Быстрый старт (Linux/macOS)

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-local.txt
python scripts/run_local.py regression
python scripts/run_local.py classification
python scripts/package_submission.py
```

Можно запустить и напрямую (из корня проекта):

```bash
python solution.py 'data/Регрессия/task.md'
python solution.py 'data/Многоклассовая классификация/task.md'
```

## Выходные файлы

После локального запуска в папке соответствующей задачи появятся:
- `submission.csv` — предсказания на тесте;
- `agent_experiments.json` — локальный журнал экспериментов.

Проверить готовые предсказания можно через `python scripts/check_submission.py 'data/Регрессия/task.md'` (для другой задачи — соответствующий путь).

## Что отправлять на платформу

Отправлять **только** `submissions/solution_upload.zip`. Этот архив содержит только `solution.py` в корне. **Не отправлять** ZIP со всей рабочей папкой и датасетами.

## LLM / секреты

Переменные `OPENAI_API_KEY`, `OPENAI_MODEL`, `OPENAI_BASE_URL` в текущем коде используются **только опционально** для обратной связи от предоставленной организаторами модели. Не кладите API-ключи в проект, git или ZIP. Запрещённые условиями внешние API не используйте.

## Текущие ограничения

Этот проект — сохранённая текущая версия, а не новая реализация полноценного автономного агента: LLM пока не выполняет собственные гипотезы, нет адаптивного многократного AutoResearch и нет проверки в Docker организаторов. Перед отправкой прочитайте `docs/CURRENT_STATUS.md`.
